import React, { useEffect, useMemo, useRef, useState } from 'react';
import { toPng } from 'html-to-image';
import {
  Search, Plus, Download, RotateCcw, Shield, Users, SlidersHorizontal,
  X, Trash2, Save, ChevronDown, Sparkles, CircleHelp, Menu
} from 'lucide-react';

const SEASONS = [
  { id: 'TOTY', name: 'TOTY', label: 'Team of the Year', cls: 'toty' },
  { id: 'UTOTY', name: 'UTOTY', label: 'Ultimate TOTY', cls: 'utoty' },
  { id: 'TOTS', name: 'TOTS', label: 'Team of the Season', cls: 'tots' },
  { id: 'HOL', name: 'HOL', label: 'Hall of Legends', cls: 'hol' },
  { id: 'UCL', name: 'UCL', label: 'Champions League', cls: 'ucl' },
  { id: 'ICON', name: 'ICON', label: 'Icon', cls: 'icon' },
  { id: 'HERO', name: 'HERO', label: 'Heroes', cls: 'hero' },
  { id: 'BASE', name: 'BASE', label: 'Base / 기타', cls: 'base' },
];

const SAMPLE_PLAYERS = [
  { id:'p1', name:'Kylian Mbappé', team:'Real Madrid', pos:'ST', ovr:108, season:'TOTY', rank:3, nation:'🇫🇷' },
  { id:'p2', name:'Cristiano Ronaldo', team:'Al Nassr', pos:'LW', ovr:107, season:'ICON', rank:2, nation:'🇵🇹' },
  { id:'p3', name:'Lionel Messi', team:'Inter Miami', pos:'RW', ovr:108, season:'HOL', rank:3, nation:'🇦🇷' },
  { id:'p4', name:'Jude Bellingham', team:'Real Madrid', pos:'CM', ovr:106, season:'TOTS', rank:2, nation:'🏴' },
  { id:'p5', name:'Kevin De Bruyne', team:'Man City', pos:'CM', ovr:106, season:'UTOTY', rank:2, nation:'🇧🇪' },
  { id:'p6', name:'Rodri', team:'Man City', pos:'CDM', ovr:105, season:'TOTS', rank:1, nation:'🇪🇸' },
  { id:'p7', name:'Vinícius Jr.', team:'Real Madrid', pos:'LW', ovr:107, season:'UTOTY', rank:3, nation:'🇧🇷' },
  { id:'p8', name:'Erling Haaland', team:'Man City', pos:'ST', ovr:107, season:'TOTY', rank:2, nation:'🇳🇴' },
  { id:'p9', name:'Virgil van Dijk', team:'Liverpool', pos:'CB', ovr:105, season:'TOTS', rank:2, nation:'🇳🇱' },
  { id:'p10', name:'Alisson', team:'Liverpool', pos:'GK', ovr:104, season:'UCL', rank:1, nation:'🇧🇷' },
  { id:'p11', name:'Mohamed Salah', team:'Liverpool', pos:'RW', ovr:106, season:'ICON', rank:2, nation:'🇪🇬' },
  { id:'p12', name:'Son Heung-min', team:'Tottenham', pos:'LW', ovr:104, season:'HERO', rank:2, nation:'🇰🇷' },
  { id:'p13', name:'Harry Kane', team:'Bayern Munich', pos:'ST', ovr:105, season:'TOTS', rank:1, nation:'🏴' },
  { id:'p14', name:'Luka Modrić', team:'Real Madrid', pos:'CM', ovr:104, season:'ICON', rank:2, nation:'🇭🇷' },
  { id:'p15', name:'Rúben Dias', team:'Man City', pos:'CB', ovr:104, season:'TOTY', rank:1, nation:'🇵🇹' },
  { id:'p16', name:'Thibaut Courtois', team:'Real Madrid', pos:'GK', ovr:105, season:'UCL', rank:2, nation:'🇧🇪' },
];

const FORMATIONS = {
  '4-3-3 공격': [
    {pos:'LW',x:18,y:18},{pos:'ST',x:50,y:11},{pos:'RW',x:82,y:18},
    {pos:'CM',x:28,y:39},{pos:'CAM',x:50,y:34},{pos:'CM',x:72,y:39},
    {pos:'LB',x:15,y:61},{pos:'CB',x:38,y:65},{pos:'CB',x:62,y:65},{pos:'RB',x:85,y:61},{pos:'GK',x:50,y:84}
  ],
  '4-2-4': [
    {pos:'LW',x:16,y:17},{pos:'ST',x:39,y:12},{pos:'ST',x:61,y:12},{pos:'RW',x:84,y:17},
    {pos:'CM',x:37,y:39},{pos:'CM',x:63,y:39},
    {pos:'LB',x:15,y:61},{pos:'CB',x:38,y:65},{pos:'CB',x:62,y:65},{pos:'RB',x:85,y:61},{pos:'GK',x:50,y:84}
  ],
  '4-3-3 수비': [
    {pos:'LW',x:18,y:18},{pos:'ST',x:50,y:12},{pos:'RW',x:82,y:18},
    {pos:'CM',x:28,y:39},{pos:'CDM',x:50,y:43},{pos:'CM',x:72,y:39},
    {pos:'LB',x:15,y:61},{pos:'CB',x:38,y:65},{pos:'CB',x:62,y:65},{pos:'RB',x:85,y:61},{pos:'GK',x:50,y:84}
  ],
  '4-2-3-1': [
    {pos:'ST',x:50,y:12},{pos:'LAM',x:25,y:29},{pos:'CAM',x:50,y:27},{pos:'RAM',x:75,y:29},
    {pos:'CDM',x:37,y:45},{pos:'CDM',x:63,y:45},
    {pos:'LB',x:15,y:61},{pos:'CB',x:38,y:65},{pos:'CB',x:62,y:65},{pos:'RB',x:85,y:61},{pos:'GK',x:50,y:84}
  ],
  '3-5-2': [
    {pos:'ST',x:38,y:12},{pos:'ST',x:62,y:12},{pos:'LM',x:12,y:35},{pos:'CM',x:34,y:34},{pos:'CAM',x:50,y:29},{pos:'CM',x:66,y:34},{pos:'RM',x:88,y:35},
    {pos:'CB',x:27,y:63},{pos:'CB',x:50,y:67},{pos:'CB',x:73,y:63},{pos:'GK',x:50,y:84}
  ],
  '4-1-2-1-2 좁게': [
    {pos:'ST',x:39,y:12},{pos:'ST',x:61,y:12},{pos:'CAM',x:50,y:31},{pos:'CM',x:30,y:43},{pos:'CM',x:70,y:43},{pos:'CDM',x:50,y:53},
    {pos:'LB',x:15,y:65},{pos:'CB',x:38,y:68},{pos:'CB',x:62,y:68},{pos:'RB',x:85,y:65},{pos:'GK',x:50,y:85}
  ],
};

const POSITIONS = ['GK','LB','CB','RB','LWB','RWB','CDM','CM','CAM','LM','RM','LW','RW','CF','ST'];
const blankSlot = () => ({ playerId: null });

function loadState() {
  try {
    const saved = localStorage.getItem('fc-squad-lab-v1');
    if (saved) return JSON.parse(saved);
  } catch {}
  const players = [...SAMPLE_PLAYERS];
  const formation = '4-3-3 공격';
  const slots = FORMATIONS[formation].map((slot, i) => ({ ...slot, playerId: players[i]?.id || null }));
  return { players, formation, slots, squadName: 'MY DREAM SQUAD' };
}
function effectiveOvr(player) { return player ? Math.min(150, Number(player.ovr || 0) + Number(player.rank || 0)) : 0; }
function seasonInfo(id) { return SEASONS.find(s => s.id === id) || SEASONS[SEASONS.length - 1]; }

function PlayerCard({ player, onClick, compact=false }) {
  const season = seasonInfo(player?.season);
  if (!player) return <button className={`empty-player ${compact ? 'compact' : ''}`} onClick={onClick} aria-label="선수 추가"><Plus size={compact ? 16 : 21}/><span>선수 추가</span></button>;
  return (
    <button className={`player-card season-${season.cls} ${compact ? 'compact' : ''}`} onClick={onClick} title={`${player.name} · ${season.name}`}>
      <div className="card-season">{season.name}</div>
      <div className="card-ovr">{effectiveOvr(player)}</div>
      <div className="card-pos">{player.pos}</div>
      <div className="card-avatar"><span>{player.nation || '⚽'}</span><Shield size={compact ? 18 : 24}/></div>
      <div className="card-name">{player.name}</div>
      <div className="card-team">{player.team || 'Custom player'}</div>
      <div className="card-rank">{'◆'.repeat(Math.max(0, Math.min(5, Number(player.rank)||0))) || '—'}</div>
    </button>
  );
}

export default function App() {
  const initial = useMemo(loadState, []);
  const [players, setPlayers] = useState(initial.players || SAMPLE_PLAYERS);
  const [formation, setFormation] = useState(initial.formation || '4-3-3 공격');
  const [slots, setSlots] = useState(initial.slots || FORMATIONS[initial.formation || '4-3-3 공격'].map(s=>({...s, playerId:null})));
  const [squadName, setSquadName] = useState(initial.squadName || 'MY DREAM SQUAD');
  const [query, setQuery] = useState('');
  const [seasonFilter, setSeasonFilter] = useState('ALL');
  const [posFilter, setPosFilter] = useState('ALL');
  const [selectedSlot, setSelectedSlot] = useState(null);
  const [showEditor, setShowEditor] = useState(false);
  const [editingPlayer, setEditingPlayer] = useState(null);
  const [mobilePanel, setMobilePanel] = useState(false);
  const [notice, setNotice] = useState('');
  const pitchRef = useRef(null);

  useEffect(() => {
    try { localStorage.setItem('fc-squad-lab-v1', JSON.stringify({players, formation, slots, squadName})); } catch {}
  }, [players, formation, slots, squadName]);

  const filteredPlayers = useMemo(() => players.filter(p => {
    const text = `${p.name} ${p.team || ''} ${p.pos} ${p.season}`.toLowerCase();
    return text.includes(query.toLowerCase()) && (seasonFilter === 'ALL' || p.season === seasonFilter) && (posFilter === 'ALL' || p.pos === posFilter);
  }), [players, query, seasonFilter, posFilter]);

  const assigned = slots.map(s => players.find(p => p.id === s.playerId)).filter(Boolean);
  const teamOvr = assigned.length ? Math.round(assigned.reduce((sum,p)=>sum+effectiveOvr(p),0) / slots.length) : 0;
  const filled = assigned.length;

  function changeFormation(next) {
    const oldPlayers = slots.map(s => s.playerId).filter(Boolean);
    const nextSlots = FORMATIONS[next].map((s,i) => ({...s, playerId: oldPlayers[i] || null}));
    setFormation(next); setSlots(nextSlots);
  }
  function choosePlayer(player) {
    if (selectedSlot === null) return;
    setSlots(prev => prev.map((s,i) => i === selectedSlot ? {...s, playerId: player.id} : s));
    setSelectedSlot(null); setNotice(`${player.name} 선수를 배치했어.`);
    setTimeout(() => setNotice(''), 2400);
  }
  function openAdd(slotIndex=null) {
    setSelectedSlot(slotIndex);
    setEditingPlayer({ id: `custom-${Date.now()}`, name:'', team:'', pos: slotIndex !== null ? slots[slotIndex]?.pos || 'ST' : 'ST', ovr:100, season:'BASE', rank:0, nation:'⚽' });
    setShowEditor(true);
  }
  function savePlayer() {
    const p = {...editingPlayer, name: editingPlayer.name.trim(), ovr: Math.max(1, Math.min(150, Number(editingPlayer.ovr)||1)), rank: Math.max(0, Math.min(5, Number(editingPlayer.rank)||0))};
    if (!p.name) { setNotice('선수 이름을 입력해 줘.'); return; }
    setPlayers(prev => prev.some(x=>x.id===p.id) ? prev.map(x=>x.id===p.id?p:x) : [...prev,p]);
    if (selectedSlot !== null) setSlots(prev=>prev.map((s,i)=>i===selectedSlot?{...s,playerId:p.id}:s));
    setShowEditor(false); setEditingPlayer(null); setSelectedSlot(null);
    setNotice('선수 카드를 저장했어.'); setTimeout(()=>setNotice(''),2400);
  }
  function editAssigned(slotIndex) {
    const p = players.find(x=>x.id===slots[slotIndex]?.playerId);
    if (p) { setSelectedSlot(slotIndex); setEditingPlayer({...p}); setShowEditor(true); }
    else { setSelectedSlot(slotIndex); }
  }
  function removeFromSlot(index) {
    setSlots(prev => prev.map((s,i)=>i===index?{...s,playerId:null}:s));
  }
  async function exportImage() {
    if (!pitchRef.current) return;
    try {
      const dataUrl = await toPng(pitchRef.current, { cacheBust: true, pixelRatio: 2, backgroundColor: '#0d3b2b' });
      const a = document.createElement('a');
      a.download = `${(squadName || 'my-squad').trim().replace(/[^a-z0-9가-힣_-]+/gi,'-')}.png`;
      a.href = dataUrl; a.click();
      setNotice('스쿼드 이미지를 저장했어!'); setTimeout(()=>setNotice(''),2400);
    } catch (e) {
      setNotice('이미지 저장에 실패했어. 브라우저에서 다시 시도해 줘.'); setTimeout(()=>setNotice(''),3000);
    }
  }
  function resetSquad() {
    if (!window.confirm('현재 스쿼드 배치를 초기화할까? 선수 데이터는 유지돼.')) return;
    setSlots(FORMATIONS[formation].map(s=>({...s,playerId:null})));
  }

  return (
    <div className="app-shell">
      <header className="topbar">
        <a className="brand" href="#" aria-label="FC Squad Lab 홈"><span className="brand-mark"><Shield size={23}/></span><span><b>FC SQUAD</b><small>LAB · MOBILE BUILDER</small></span></a>
        <div className="top-actions">
          <span className="autosave"><span className="live-dot"/> 자동 저장</span>
          <button className="button button-quiet mobile-menu" onClick={()=>setMobilePanel(!mobilePanel)}><Menu size={17}/> 선수 목록</button>
          <button className="button button-primary" onClick={exportImage}><Download size={17}/> 이미지 저장</button>
        </div>
      </header>

      <main className="main-wrap">
        <section className="hero">
          <div className="hero-copy">
            <div className="eyebrow"><Sparkles size={14}/> YOUR CLUB. YOUR LEGACY.</div>
            <h1>나만의 드림 스쿼드<span>.</span></h1>
            <p>선수를 고르고, 시즌을 조합하고, 너만의 베스트 11을 완성해 봐.</p>
          </div>
          <div className="hero-stats">
            <div><span>TEAM OVR</span><strong>{teamOvr || '—'}</strong></div>
            <div><span>PLAYERS</span><strong>{filled}<i>/{slots.length}</i></strong></div>
          </div>
        </section>

        <div className="workspace">
          <section className="pitch-column">
            <div className="section-head">
              <div><span className="section-kicker">TACTICAL BOARD</span><h2>스쿼드 보드</h2></div>
              <div className="board-actions">
                <label className="formation-select"><SlidersHorizontal size={15}/><select value={formation} onChange={e=>changeFormation(e.target.value)} aria-label="포메이션 선택">{Object.keys(FORMATIONS).map(f=><option key={f}>{f}</option>)}</select><ChevronDown size={14}/></label>
                <button className="icon-button" title="배치 초기화" onClick={resetSquad}><RotateCcw size={17}/></button>
              </div>
            </div>
            <div className="pitch" ref={pitchRef}>
              <div className="pitch-topline"><span>FC SQUAD LAB</span><span>{squadName || 'MY DREAM SQUAD'}</span></div>
              <div className="pitch-lines"><div className="halfway"/><div className="center-circle"/><div className="penalty-box top-box"/><div className="goal-box top-goal"/><div className="penalty-box bottom-box"/><div className="goal-box bottom-goal"/></div>
              {slots.map((slot, i) => {
                const player = players.find(p=>p.id===slot.playerId);
                return <div key={`${formation}-${i}`} className="pitch-slot" style={{left:`${slot.x}%`,top:`${slot.y}%`}}>
                  <PlayerCard player={player} compact onClick={()=>{ if(player) editAssigned(i); else setSelectedSlot(i); }}/>
                  {player && <button className="slot-edit" title="선수 교체" onClick={()=>setSelectedSlot(i)}><RotateCcw size={11}/></button>}
                </div>;
              })}
              <div className="pitch-footer"><span>BUILD YOUR XI</span><span>{formation}</span></div>
            </div>
            <div className="squad-bottom">
              <label className="name-input"><span>스쿼드 이름</span><input value={squadName} onChange={e=>setSquadName(e.target.value)} maxLength={32} placeholder="MY DREAM SQUAD"/></label>
              <div className="bottom-summary"><span><Users size={15}/> 배치된 선수 <b>{filled}/{slots.length}</b></span><span><Shield size={15}/> 팀 OVR <b>{teamOvr || '—'}</b></span></div>
            </div>
          </section>

          <aside className={`player-panel ${mobilePanel?'panel-open':''}`}>
            <div className="panel-head">
              <div><span className="section-kicker">PLAYER DATABASE</span><h2>선수 선택</h2></div>
              <button className="icon-button add-player" onClick={()=>openAdd(null)} title="선수 직접 추가"><Plus size={18}/></button>
              <button className="icon-button close-panel" onClick={()=>setMobilePanel(false)}><X size={18}/></button>
            </div>
            {selectedSlot !== null && <div className="selecting-banner"><span><Sparkles size={14}/> {slots[selectedSlot]?.pos} 포지션 선수 선택 중</span><button onClick={()=>setSelectedSlot(null)}>취소</button></div>}
            <div className="search-box"><Search size={17}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="선수, 팀, 시즌 검색..." /><kbd>/</kbd></div>
            <div className="filter-row">
              <select value={seasonFilter} onChange={e=>setSeasonFilter(e.target.value)} aria-label="시즌 필터"><option value="ALL">모든 시즌</option>{SEASONS.map(s=><option key={s.id} value={s.id}>{s.name}</option>)}</select>
              <select value={posFilter} onChange={e=>setPosFilter(e.target.value)} aria-label="포지션 필터"><option value="ALL">모든 포지션</option>{POSITIONS.map(p=><option key={p}>{p}</option>)}</select>
            </div>
            <div className="database-note"><CircleHelp size={14}/> 예시 선수 데이터가 포함되어 있어. 직접 추가해도 돼.</div>
            <div className="player-list">
              {filteredPlayers.map(player=><button className="player-row" key={player.id} onClick={()=>selectedSlot!==null?choosePlayer(player):(setEditingPlayer({...player}),setShowEditor(true),setSelectedSlot(null))}>
                <div className={`mini-card season-${seasonInfo(player.season).cls}`}><span>{effectiveOvr(player)}</span><small>{player.pos}</small></div>
                <div className="player-row-main"><b>{player.name}</b><span>{player.nation || '⚽'} {player.team || 'Custom player'}</span><div className="player-tags"><i className={`season-tag ${seasonInfo(player.season).cls}`}>{player.season}</i><span>{'◆'.repeat(Number(player.rank)||0) || '기본'}</span></div></div>
                <span className="row-chevron">{selectedSlot!==null?'배치':'편집'} <Plus size={13}/></span>
              </button>)}
              {filteredPlayers.length===0 && <div className="empty-results"><Search size={24}/><b>검색 결과가 없어</b><span>검색어를 바꾸거나 새 선수를 추가해 봐.</span><button className="button button-outline" onClick={()=>openAdd(null)}><Plus size={15}/> 선수 직접 추가</button></div>}
            </div>
            <button className="button button-outline add-player-wide" onClick={()=>openAdd(null)}><Plus size={16}/> 새 선수 / 카드 등록</button>
          </aside>
        </div>

        <section className="season-guide">
          <div className="season-guide-head"><div><span className="section-kicker">CARD COLLECTION</span><h2>카드 시즌 컬렉션</h2></div><p>시즌마다 다른 카드 스타일을 적용해 봐.</p></div>
          <div className="season-swatches">{SEASONS.map(s=><button key={s.id} className={`season-swatch season-${s.cls}`} onClick={()=>{setSeasonFilter(s.id);document.querySelector('.player-panel')?.scrollIntoView({behavior:'smooth',block:'start'});}}><span className="swatch-gem">✦</span><b>{s.name}</b><small>{s.label}</small></button>)}</div>
        </section>

        <footer><span>FC SQUAD LAB</span><span>팬 제작 스쿼드 메이커 · EA SPORTS FC Mobile과 공식 제휴 관계가 없습니다.</span></footer>
      </main>

      {notice && <div className="toast"><Sparkles size={15}/>{notice}</div>}

      {showEditor && editingPlayer && <div className="modal-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget){setShowEditor(false);setEditingPlayer(null);}}}>
        <form className="player-modal" onSubmit={e=>{e.preventDefault();savePlayer();}}>
          <div className="modal-head"><div><span className="section-kicker">{players.some(p=>p.id===editingPlayer.id)?'EDIT PLAYER CARD':'CREATE PLAYER CARD'}</span><h2>{players.some(p=>p.id===editingPlayer.id)?'선수 카드 편집':'선수 직접 추가'}</h2></div><button type="button" className="icon-button" onClick={()=>{setShowEditor(false);setEditingPlayer(null);}}><X size={18}/></button></div>
          <div className="modal-preview"><PlayerCard player={editingPlayer} compact/></div>
          <div className="form-grid">
            <label className="field full"><span>선수 이름 *</span><input autoFocus value={editingPlayer.name} onChange={e=>setEditingPlayer({...editingPlayer,name:e.target.value})} placeholder="예: Son Heung-min" required maxLength={42}/></label>
            <label className="field"><span>소속 팀</span><input value={editingPlayer.team||''} onChange={e=>setEditingPlayer({...editingPlayer,team:e.target.value})} placeholder="예: Tottenham" maxLength={40}/></label>
            <label className="field"><span>국가 / 아이콘</span><input value={editingPlayer.nation||''} onChange={e=>setEditingPlayer({...editingPlayer,nation:e.target.value})} placeholder="🇰🇷" maxLength={8}/></label>
            <label className="field"><span>포지션</span><select value={editingPlayer.pos} onChange={e=>setEditingPlayer({...editingPlayer,pos:e.target.value})}>{POSITIONS.map(p=><option key={p}>{p}</option>)}</select></label>
            <label className="field"><span>기본 OVR</span><input type="number" min="1" max="150" value={editingPlayer.ovr} onChange={e=>setEditingPlayer({...editingPlayer,ovr:e.target.value})}/></label>
            <label className="field"><span>카드 시즌</span><select value={editingPlayer.season} onChange={e=>setEditingPlayer({...editingPlayer,season:e.target.value})}>{SEASONS.map(s=><option key={s.id} value={s.id}>{s.name} · {s.label}</option>)}</select></label>
            <label className="field"><span>강화 단계 (0~5)</span><select value={editingPlayer.rank} onChange={e=>setEditingPlayer({...editingPlayer,rank:Number(e.target.value)})}>{[0,1,2,3,4,5].map(n=><option key={n} value={n}>{n===0?'강화 없음':`+${n} 강화`}</option>)}</select></label>
          </div>
          <div className="rank-explainer">표시 OVR = 기본 OVR + 강화 단계 (최대 150). 게임의 실제 강화 계산식과는 다를 수 있어.</div>
          <div className="modal-actions">
            {players.some(p=>p.id===editingPlayer.id) && <button type="button" className="button button-danger" onClick={()=>{if(window.confirm('이 선수를 데이터베이스에서 삭제할까?')){setPlayers(prev=>prev.filter(p=>p.id!==editingPlayer.id));setSlots(prev=>prev.map(s=>s.playerId===editingPlayer.id?{...s,playerId:null}:s));setShowEditor(false);setEditingPlayer(null);}}}><Trash2 size={15}/> 삭제</button>}
            <button type="button" className="button button-quiet" onClick={()=>{setShowEditor(false);setEditingPlayer(null);}}>취소</button>
            <button type="submit" className="button button-primary"><Save size={15}/> 저장</button>
          </div>
        </form>
      </div>}
      <button className="floating-help" title="안내" onClick={()=>setNotice('선수 카드를 누르면 편집, 빈 슬롯을 누르면 선수 배치를 시작할 수 있어.')}><CircleHelp size={19}/></button>
    </div>
  );
}